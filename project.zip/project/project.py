import turtle 
from google.cloud import texttospeech
from pygame import mixer  # Load the popular external library
from slugify import slugify
from os import path

# do "source setup.sh" in the terminal
# pip3 install python-slugify
# follow google cloud instructions


turtle.setup(width=650, height=2300, startx=1, starty=1)
screen = turtle.Screen()

# turtle.screensize(1000, 2500)


board = turtle.Turtle()

def text_to_speech(source, text):
	""" send text to google t2s service, and play the file received """
	print(source, text)

	# Instantiates a client
	client = texttospeech.TextToSpeechClient()

	# Set the text input to be synthesized
	synthesis_input = texttospeech.types.SynthesisInput(text=text)

	# Build the voice request, select the language code ("en-US") and the ssml
	# voice gender ("neutral")
	voice = texttospeech.types.VoiceSelectionParams(
	    language_code='en-US',
	    ssml_gender=texttospeech.enums.SsmlVoiceGender.NEUTRAL)

	# Select the type of audio file you want returned
	audio_config = texttospeech.types.AudioConfig(
	    audio_encoding=texttospeech.enums.AudioEncoding.MP3)

	# Perform the text-to-speech request on the text input with the selected
	# voice parameters and audio file type
	response = client.synthesize_speech(synthesis_input, voice, audio_config)

	file_name = slugify(text) + '.mp3'
	if not path.exists(file_name):
		# The response's audio_content is binary.
		with open(file_name, 'wb') as out:
		    # Write the response to the output file.
		    out.write(response.audio_content)
		    print('Downloading audio content to file ' + file_name)
	else:
		print('Using existing file ' + file_name)


	print('playing the mp3 file')
	mixer.init()
	mixer.music.load('./' + file_name)
	mixer.music.play()


# hover event
in_rect = False

def hover(event):
	x, y = event.x, event.y
	#print('x:', x, 'y:', y)
	global in_rect


	if 270 < x < 380 and 0 < y < 90:
	  	if in_rect is False:
		  	in_rect = True
		  	text_to_speech('start', 'start')


	elif 230 < x < 430 and 115 < y < 175:
	  	if in_rect is False:
		  	in_rect = True
		  	text_to_speech('in rectangle 1', 'stand in front of the door')


	elif 230 < x < 430 and 205 < y < 265:
	  	if in_rect is False:
		  	in_rect = True
		  	text_to_speech('in rectangle 2', 'scan by camera')


	elif 230 < x < 430 and 295 < y < 355:
	  	if in_rect is False:
		  	in_rect = True
		  	text_to_speech('in rectangle 3', 'check stored memory')

	elif 230 < x < 430 and 550 < y < 610:
	  	if in_rect is False:
		  	in_rect = True
		  	text_to_speech('in rectangle 4', 'open the door')

	elif 230 < x < 430 and 640 < y < 700:
	  	if in_rect is False:
		  	in_rect = True
		  	text_to_speech('in rectangle 5', 'Refresh stored memory')


	elif 300 < x < 350 and 490 < y < 530:
	  	if in_rect is False:
		  	in_rect = True
		  	text_to_speech('if condition Yes', 'yes')


	elif 370 < x < 430 and 400 < y < 470:
	  	if in_rect is False:
		  	in_rect = True
		  	text_to_speech('if condition No', 'no')



	elif 250 < x < 400 and 710 < y < 815:
	  	if in_rect is False:
		  	in_rect = True
		  	text_to_speech('end', 'end')

	else:
		in_rect = False

def draw_link():
	length=30
	board.pendown()
	board.forward(length)
	board.right(90)


def draw_rect(label):
	width = 200
	height = 60

	# link 
	draw_link()


	# create the rect
	board.forward(width/2)
	board.left(90)
	board.forward(height)
	board.left(90)
	board.forward(width)
	board.left(90)
	board.forward(height)
	board.left(90)
	board.forward(width/2)


	# enter rect for label
	board.penup()
	board.left(90)
	board.forward(height/2)
	board.right(90)
	board.pendown()

	# label
	board.write(label, font=('Courier', 12, 'italic'), align="center")

	# exit rect after label
	board.penup()
	board.left(90)
	board.forward(height/2)
	board.pendown()


canvas = turtle.getcanvas()
canvas.bind('<Motion>', hover)

board.penup()
board.goto(0, 330)
board.speed(30)

board.pendown()
board.circle(50)

# draw over
board.right(90)


draw_rect("stand in front of the door")
draw_rect("scan by camera")
draw_rect("check stored memory")

draw_link()


# create the Diamond
board.left(45)
board.forward(100)
board.left(90)
board.forward(100)
board.left(90)
board.forward(100)
board.left(90)
board.forward(100)
board.left(45)

# go down to the center of the rect to write text
board.penup()
board.left(90)
board.forward(90)
board.right(90)
board.pendown()


# draw over
board.penup()
board.left(90)
board.forward(50)

board.write("Yes ", font=('Courier', 14, 'italic'), align="center")


draw_rect("open the door ")
draw_rect("Refresh stored memory")


draw_link()

board.circle(60)
board.penup()
board.left(90)
board.forward(10)
board.right(90)
board.pendown()
board.circle(60 - 10)

board.penup()
board.right(90)
board.forward(290)
board.right(90)
board.forward(70)



board.write("No", font=('Courier', 14, 'italic'))

# feedback line
board.pendown()
board.forward(200)
board.left(90)
board.forward(310)
board.left(90)
board.forward(170)

board.penup()
board.forward(100)
board.right(90)
board.forward(100)
board.pendown()
board.write("START", font=('Courier', 14, 'italic'), align="center")

board.penup()
board.left(180)
board.forward(750)
board.pendown()
board.write("END", font=('Courier', 14, 'italic'), align="center")

board.penup()
board.forward(100) # move out of the window

turtle.done()





